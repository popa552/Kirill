package com.kirill.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(32,32,32,32);
        box.setBackgroundColor(Color.rgb(18,18,18));

        TextView title = new TextView(this);
        title.setText("KIRILL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("\nПрототип готов.\nNatural-glava\nБаланс: 100 000 000");
        info.setTextColor(Color.WHITE);
        info.setTextSize(20);
        info.setGravity(Gravity.CENTER);

        box.addView(title);
        box.addView(info);
        setContentView(box);
    }
}
